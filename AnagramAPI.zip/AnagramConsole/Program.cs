﻿using System;
using System.Collections.Generic;
using System.IO;
using AnagramLibrary;


namespace AnagramConsole
{
    class Program
    {
        readonly Anagram anagram = new Anagram();
        void Main(string[] args)
        {

            if(args[0].Equals("check"))
            {
                bool res = anagram.CheckAnagram(args[1], args[2]);
                if(res==true)
                {
                    Console.WriteLine("'"+args[1]+"' and '"+args[2]+"' are anagrams." );
                } else
                {
                    Console.WriteLine("'" + args[1] + "' and '" + args[2] + "' are no anagrams.");
                }
                
            } else if(args[0].Equals("getKnown"))
            {
                List<string> res = anagram.GetKnown(args[1]);
                foreach(string word in res)
                {
                    Console.WriteLine(word);
                }
            }
            
        }
        /*
        private static List<string> getKnown(string word)
        {
            List<string> result = new List<string>();
            string line;
            using (StreamReader sr = new StreamReader(@"C:\Users\chris\source\repos\MCSimpleSpellChecker\AnagramConsole\Dictionary.txt"))
            {
                while (sr.Peek() >= 0)
                {
                    line =  sr.ReadLine();
                    var dictionaryWords = line
                        .Replace(" ", "")
                        .Replace("\r", string.Empty)
                        .Split('=');

                    //Console.WriteLine(dictionaryWords[0] + " " + dictionaryWords[1]);
                     if(dictionaryWords[0].Equals(word) || dictionaryWords[1].Equals(word))  
                        if(checkAnagram(word,dictionaryWords[1]))
                        {
                            if(dictionaryWords[1].Equals(word) == false)
                            {
                                result.Add(dictionaryWords[1]);
                            }
                        }
                        if (checkAnagram(word, dictionaryWords[0]))
                        {
                            if (dictionaryWords[0].Equals(word) == false)
                            {
                                result.Add(dictionaryWords[1]);
                            }
                        }
                }
            }
            return result;
        }

        private static Boolean checkAnagram(string v1, string v2)
        {
            string[] data = new string[2];
            data[0] = v1;
            data[1] = v2;
            return checkAnagram(data);
        }
        private static Boolean checkAnagram(string[] data)
        {
            if (data[0].Length > 0)
            {
                data[1] = deleteCharacter(data, data[0][0]);
                data[0] = data[0].Remove(0, 1);
                if (data[1] == null)
                {
                    return false;
                }
                //Console.WriteLine(data[0] + " ---> "+data[1]);
            } else
            {
                return true;
            }
            return checkAnagram(data);
            
        }

        private static string deleteCharacter(string[] data,char sign)
        {
            for (int i=0; i<data[1].Length;i++)
            {
                if(data[1][i]==sign)
                {
                    return data[1] = data[1].Remove(i, 1);
                    
                }
            }
            return null;
        }
    */
    }
}
