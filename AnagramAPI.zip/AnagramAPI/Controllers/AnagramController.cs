﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AnagramLibrary;

namespace AnagramAPI.Controllers
{
    

    [ApiController]
    [Route("/api")]
    public class AnagramController : ControllerBase
    {
        private Anagram anagram = new Anagram();

        [HttpGet]
        public IActionResult GetItem()
        {

            return Ok("Test Test");

        }

        public class JsonAnagram
        {
            public string w1 { get; set; }
            public string w2 { get; set; }
        }

        [HttpPost]
        [Route("checkAnagram")]
        public IActionResult AddAnagram([FromBody] JsonAnagram parm)
        {
            string w1 = parm.w1;
            string w2 = parm.w2;

            bool res = anagram.CheckAnagram(w1, w2);
            if (res == true)
            {
                return Ok("'" + w1 + "' and '" + w2 + "' are anagrams.");
            }
            return BadRequest("'" + w1 + "' and '" + w2 + "' are no anagrams.");
        
        }

        

        [HttpGet]
        [Route("getKnownAnagrams")]
        public HttpPostAttribute GetKnownAnagrams([FromQuery]string word)
        {
            List<string> res = anagram.GetKnown(word);
            
            if(res.Count>0)
            {
                //return list
                return null;
            }

            //return NotFound();
            return null;
        }

        /*
        private bool checkAnagram(string w1, string w2)
        {
            throw new NotImplementedException();
        }


        private static List<string> getKnown(string word)
        {
            List<string> result = new List<string>();
            string line;
            using (StreamReader sr = new StreamReader(@"C:\Users\chris\source\repos\MCSimpleSpellChecker\AnagramConsole\Dictionary.txt"))
            {
                while (sr.Peek() >= 0)
                {
                    line = sr.ReadLine();
                    var dictionaryWords = line
                        .Replace(" ", "")
                        .Replace("\r", string.Empty)
                        .Split('=');

                    //Console.WriteLine(dictionaryWords[0] + " " + dictionaryWords[1]);
                    if (dictionaryWords[0].Equals(word) || dictionaryWords[1].Equals(word))
                        if (checkAnagram(word, dictionaryWords[1]))
                        {
                            if (dictionaryWords[1].Equals(word) == false)
                            {
                                result.Add(dictionaryWords[1]);
                            }
                        }
                    if (checkAnagram(word, dictionaryWords[0]))
                    {
                        if (dictionaryWords[0].Equals(word) == false)
                        {
                            result.Add(dictionaryWords[1]);
                        }
                    }
                }
            }
            return result;
        }

        private static Boolean heckAnagram(string v1, string v2)
        {
            string[] data = new string[2];
            data[0] = v1;
            data[1] = v2;
            return checkAnagram(data);
        }


        private static Boolean checkAnagram(string[] data)
        {
            if (data[0].Length > 0)
            {
                data[1] = deleteCharacter(data, data[0][0]);
                data[0] = data[0].Remove(0, 1);
                if (data[1] == null)
                {
                    return false;
                }
                //Console.WriteLine(data[0] + " ---> "+data[1]);
            }
            else
            {
                return true;
            }
            return checkAnagram(data);

        }

        private static string deleteCharacter(string[] data, char sign)
        {
            for (int i = 0; i < data[1].Length; i++)
            {
                if (data[1][i] == sign)
                {
                    return data[1] = data[1].Remove(i, 1);

                }
            }
            return null;
        }
    */
    }
}
